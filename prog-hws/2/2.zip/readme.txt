Resourses used are::

1. http://natureofcode.com/book/chapter-8-fractals/
2. https://www.tutorialspoint.com/computer_graphics/computer_graphics_fractals.htm