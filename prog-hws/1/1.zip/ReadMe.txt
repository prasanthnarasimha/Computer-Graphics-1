Open index.html in a web browser
Click on the canvas to start drawing
Click again to conclude the drawing
I have used w3 schools website as a resource to properly use canvas.
