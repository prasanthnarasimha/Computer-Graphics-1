After opening the webpage, you can see the mesh which is textured with grass. Also, you can see the some solid geometric objects : sphere, and cubes.

We can see how light effect changes the shadows and dispaly of geometric objects in this submission.

In the next submission, I will try to provide the user ability to navigate through the scene using keyboard keys.