List of files are:
    1. week3.html
    2. light.html
    3. app.js
    4. app2.js
    5. three.min.js
    6. vertical_logo_with_tag.png

The png file is the logo of the UML.
three.min.js is the minified version of three js.

Rest of the files are HTML and JS files used in this week