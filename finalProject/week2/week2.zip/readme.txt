I have created perspective projections of an object cube. I also coded 3d transformations of the house model that I created during previous week's submission.
List of Files:
    1. week2.html
    2. app.js
    3. style1.css
    4. gl-matrix.js (reference: https://github.com/toji/gl-matrix)

I used reference 3 to code 3D transformations

I also coded a 3D object cube in WebGL. I have used gl-matrix.js to compute complex matrix calculations. Next week, I will add texture to the object cube that I created. 
I will also try to add lighting and shadow transformations in the coming week's submissions.

References:
    1. https://github.com/toji/gl-matrix - glMatrix is very usefull in computing matrix multiplications
    2. https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API
    3. https://www.w3schools.com/css/css3_animations.asp